import { AppClient } from '@vtex/api'

export default class Analytics extends AppClient {}
