export const COURSE_ENTITY = 'course_backend_product_list'
