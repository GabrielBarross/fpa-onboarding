export function getRandomNumber() {
  return Math.round(Math.random() * 100)
}
