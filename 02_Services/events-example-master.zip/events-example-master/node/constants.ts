export const ENABLED_GLOBALLY = true

export const EVENT_EXAMPLE = 'send-event'

export const TIME_INTERVAL = 10
