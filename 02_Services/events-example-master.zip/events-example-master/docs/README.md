# Events Example

App in VTEX IO designed to send events using a time interval and IO's Events system.

### How it works?
